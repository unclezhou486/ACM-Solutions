#include <bits/stdc++.h>
#define int long long

using namespace std;

void solve(){
    cout<<"test\n";
}

signed main(){
signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t=1;
    cin>>t;
    while(t--){
        solve();
    }
    return 0;
}